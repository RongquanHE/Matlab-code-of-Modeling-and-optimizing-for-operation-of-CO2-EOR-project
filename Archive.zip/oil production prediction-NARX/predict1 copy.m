function [oilPrediction] = predict1(ot,it)
s=readtable("oil prodution prediction.xlsx");
xt=s.injection;
yt=s.oil_production;
xt(end+1)=it;
yt(end+1)=ot;
X = tonndata(xt,false,false);
T = tonndata(yt,false,false);
load net.mat;
nets = removedelay(net);
nets.name = [net.name ' - Predict One Step Ahead'];
%view(nets)
[xs,xis,ais,ts] = preparets(nets,X,{},T);
ys = nets(xs,xis,ais);
oilPrediction=ys(end);
end