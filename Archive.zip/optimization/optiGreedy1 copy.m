function [p] = optiGreedy1(x)
a=@predict1
b=@predict2
s=readtable("oil prodution prediction.xlsx");
xt=s.injection;
yt=s.oil_production;
load net.mat;
nets = removedelay(net);
nets.name = [net.name ' - Predict One Step Ahead'];

xt(end+1)=194;
yt(end+1)=181636.5;
o1=a(xt,yt,nets);
oil1=o1-181636.5;
electricity1=b(-3,x(1),(x(1)+x(2)),800,oil1);
xt(end+1)=x(1)+x(2);
yt(end+1)=o1;
o2=a(xt,yt,nets);
oil2=o2-o1;
%electricity2=b(-2,x(3),(x(3)+x(4)),800,oil2);

p=(electricity1)*0.0857+(x(2))*45.7-(oil2)*280
end